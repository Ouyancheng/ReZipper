open the real archives in-app
